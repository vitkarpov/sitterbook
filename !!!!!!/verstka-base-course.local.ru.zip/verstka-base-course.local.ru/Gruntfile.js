module.exports = function (grunt) {
  grunt.initConfig({
    htmlmin: {
      target: {
        options: {
          //removeComments: true
          //collapseWhitespace: true
        },
        files: {
          'dist/index.php': 'src/index.php'
        }
      }
    },

    less: {
      options: {
        compress: true
      },
      development: {
        files: {
          "src/css/style.css": "src/css/style.less",
          "dist/css/ie.css": "src/css/ie.less"
        }
      }
    },

    concat: {
      js: {
        src: ["src/js/jquery-1.9.1.min.js", "src/js/bootstrap.min.js", "src/js/scroll.js", "src/js/analytics.js", "src/js/flipclock.js", "src/js/flipclock_start.js"],
        dest: "src/js/main.js"
      },
      css: {
        src: ["src/css/bootstrap.min.css", "src/css/style.css", "src/css/flipclock.css"],
        dest: "dist/css/style.css"
      }
    },

    uglify: {
      options: {
        compress: true
      },
      target: {
        src: "src/js/main.js",
        dest: "dist/js/main.min.js"
      }
    },

    watch: {
      scripts : {
        files: ["src/css/*", "src/js/*", "src/*.html", "src/*.php"],
        tasks: ["css-html"]
      }
    }
  });

  grunt.loadNpmTasks("grunt-contrib-htmlmin");
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks("grunt-contrib-concat");
  grunt.loadNpmTasks("grunt-contrib-uglify");
  grunt.loadNpmTasks("grunt-contrib-watch");

  grunt.registerTask('html', ['htmlmin']);
  grunt.registerTask('css-html', ['htmlmin', 'less', 'concat']);
  grunt.registerTask('full', ['htmlmin', 'less', 'concat', 'uglify']);
};
