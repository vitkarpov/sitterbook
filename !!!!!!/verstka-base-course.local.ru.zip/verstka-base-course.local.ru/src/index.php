<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">

	<meta property="og:type" content="article">
	<meta property="og:title" content="Как научиться верстать адаптивную HTML-страницу из PSD-макета?">
	<meta property="og:description" content='Курс "Технология вёрстки адаптивной веб-страницы"'>
	<meta property="og:url" content="http://verstka-base-course.makeweb.me/">
	<meta property="og:image" content="http://verstka-base-course.makeweb.me/images/opengraph_image.png">

	<title>Курс по верстке адаптивной веб-страницы</title>

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic' rel='stylesheet'>
	<link rel="stylesheet" href="css/style.css">

	<!--
	<script src="//vk.com/js/api/openapi.js?117"></script>

	<script>
		VK.init({apiId: 5069433, onlyWidgets: true});
	</script>
	-->

	<!--[if lte IE 9]>
		<link rel="stylesheet" href="css/ie.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>

<body data-spy="scroll" data-target="#menu" data-offset="170">

	<!-- Навигационное меню -->
	<nav class="navbar-default" id="menu">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#links">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>

			<div class="collapse navbar-collapse" id="links">
				<ul class="nav navbar-nav clearfix">
					<li><a href="#main">Главная</a></li>
					<li><a href="#what-you-get">Что ты получишь?</a></li>
					<li><a href="#features">Преимущества</a></li>
					<li><a href="#author">Об авторе</a></li>
					<li><a href="#about-course">Об обучении</a></li>
					<li><a href="#testimonials">Отзывы</a></li>
					<li><a href="#prices">Цены</a></li>
				</ul>
			</div>
		</div>
	</nav>


	<!-- Главная часть с видео -->
	<div id="main">
		<div class="container">
			<h1>Курс "Базовая технология верстки адаптивной веб-страницы"</h1>
			<p class="sub">Узнай подробности из видео ниже:</p>

			<div id="screen">
				<div class="slider theme-default">
					<!-- <iframe src="https://www.youtube.com/embed/SAyVimxEdaI" frameborder="0" allowfullscreen></iframe> -->
					<!-- ?autoplay=1 -->
				</div>
			</div>

			<div id="panel-under">
				<a href="#prices" class="btn btn-large btn-danger">Участвовать бесплатно</a>
			</div>
		</div>
	</div>


	<!-- Этот курс для тебя, если: -->
	<section id="what-you-get" class="container">
		<div class="header">
			<h1>Этот курс для тебя, если:</h1>
		</div>

		<div class="features-list clearfix">
			<div class="col-sm-6 left">
				<p>Ты дизайнер, который хочет освоить верстку и предлагать эту услугу в дополнение к созданию дизайна, а также создавать динамические прототипы своих макетов, наглядно показывающие верстальщику, чего ты хочешь от него добиться.</p>
				<p class="type">[ДИЗАЙНЕР]</p>
			</div>

			<div class="col-sm-6 right">
				<p>Ты новичок в верстке, с опытом в несколько сверстанных макетов и хочешь получить пошаговую универсальную технологию верстки современных адаптивных веб-страниц, чтобы начать активную работу на фрилансе или в веб-студии.</p>
				<p class="type">{ВЕРСТАЛЬЩИК}</p>
			</div>
		</div>
	</section>


	<!-- Почему именно этот курс? -->
	<section id="features">
		<div class="container">
			<div class="col-md-12">
				<div class="header grey">
					<h1>Почему именно этот курс?</h1>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Домашние задания</h2>
					<div>
						<img src="images/features/homework.png" alt="">
						<p>К каждому уроку прилагается домашнее задание, вполнив которое, ты закрепляешь материал урока на конкретном примере и не позволяешь теории выветриться из головы.</p>
					</div>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Сопровождение на каждом этапе</h2>
					<div>
						<img src="images/features/assist.png" alt="">
						<p>Если ты сталкиваешься с проблемой, то Наставник курса помогает тебе её решить и поясняет почему это произошло. Таким образом, ты не остановишься на половине пути.</p>
					</div>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Обратная видеосвязь</h2>
					<div>
						<img src="images/features/video.png" alt="">
						<p>В этом курсе Наставник прямо на видео разбирает все твои ошибки по отправленным ответам на домашние задания и дает верное направление и полезные советы.</p>
					</div>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Просто для понимания</h2>
					<div>
						<img src="images/features/easy.png" alt="">
						<p>Последовательный стиль изложения данного курса поможет тебе закрыть имеющиеся пробелы в знаниях и заменить старые подходы и приемы на более эффективные новые.</p>
					</div>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Повышение уверенности в себе</h2>
					<div>
						<img src="images/features/sure.png" alt="">
						<p>Практика данного курса и поможет тебе стать уверенным в собственных навыках и назначать за свою работу хороший ценник, ранее для тебя недостижимый.</p>
					</div>
				</div>

				<div class="item col-md-6 clearfix">
					<h2>Доведение до результата</h2>
					<div>
						<img src="images/features/result.png" alt="">
						<p>Ты закончишь курс только тогда, когда сделаешь макет до конца и отработаешь все необходимые приемы. Контроль качества результата всегда на самой высокой планке!</p>
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- Об авторе -->
	<section id="author" class="container">
		<div class="header">
			<h1>Об авторе курса</h1>
		</div>

		<div class="teams-list clearfix">
			<div class="col-md-6 col-md-offset-3">
				<div>
					<img src="images/kran.jpg" alt="Автор курса Никита Красник">
				</div>

				<div class="header">
					<h2>Никита Красник</h2>
				</div>

				<p>Я практикующий веб-разработчик и фрилансер. За все время работы и изучения технологий в этой сфере, у меня накопился приличный опыт, которым я и постарался с тобой максимально поделиться в этом курсе.</p>
				<br>
				<p>Также, я являюсь основателем проекта <a href="https://vk.com/makewebme" target="_blank">MakeWeb.me</a>, который посвящен фронтэнд веб-разработке и верстке, в частности. На <a href="http://www.youtube.com/channel/UCt36CWL85NGtOgUMZ2X6x5g?sub_confirmation=1" target="_blank">YouTube-канале MakeWeb.me</a> ты можешь посмотреть различные актуальные видеоролики и переводы моего авторства (и не только) по соответствующей теме.</p>
			</div>
		</div>
	</section>


	<!-- Как будет проходить обучение? -->
	<section id="about-course">
		<div id="how-it-works">
			<div class="container">
				<div class="header grey">
					<h1>Как будет проходить обучение?</h1>
				</div>

				<p class="text-center">Посмотри короткий ролик, в котором рассказано о том, каким образом происходит работа по домашним заданиям:</p>

				<!-- <iframe class="works-video" src="https://www.youtube.com/embed/EzINc309chE" frameborder="0" allowfullscreen></iframe> -->
				<br>
				<p>Процесс сдачи и проверки домашних заданий (ДЗ) организован через удобный сервис Антитренинги, где ты сможешь получить доступ к видеозаписям уроков, текстам ДЗ и дополнительным материалам.</p>

				<p><strong>Все очень просто:</strong> ты выполняешь ДЗ и отправляешь его. После этого, ты получаешь подробный ответ в формате видео с тщательным разбором ошибок и недочетов. Наставник курса со всех сторон рассмотрит твою работу и подскажет, что можно сделать лучше и каким способом реализовать ту или иную часть будущей странички.</p>

				<p>Так ты напрямую получаешь проверенную информацию и эффективные методики. При таком подходе большая часть пробелов будет заполнена и у тебя появится целостное понимание того, с чем ты имеешь дело!</p>
				<br>

				<h2>Какой уровень знаний и умений нужно иметь для освоения материала курса?</h2>

				<p>Тебе нужно знать основы HTML и CSS, а также иметь несколько сверстанных макетов (хотя это и не обязательно).</p>
				<br>

				<h2>Когда начало?</h2>

				<p>Материал курса представлен в формате видеозаписей и доступен для прохождения в любой момент.</p>
				<br>

				<h2>Есть ли ограничения по времени?</h2>

				<p>На прохождение курса тебе дается два месяца. Этого времени достаточно для вдумчивого прохождения и освоения материала всего курса, при этом все не растягивается до бесконечности.</p>

				<p>ДЗ проверяются в будние дни с понедельника по пятницу, так что если ты намерен пройти курс за две недели, то ты легко сможешь это сделать - нужно будет лишь упорно работать.</p>
				<br>

				<h2>Сколько попыток сдачи ДЗ?</h2>

				<p>На количество сдач каждого ДЗ отводится символическое ограничение в 10 попыток, однако на практике этого не происходит, потому что Наставник при обнаружении пробелов в твоем понимании, даст ссылки на материалы для самостоятельного изучения.</p>

				<p>Это простимулирует развитие твоих способности к самообучению, что очень важно ввиду скорости развития сегодняшних технологий.</p>
			</div>
		</div>


		<!-- План работы -->
		<div id="plan" class="container">
			<div class="header">
				<h1>План работы</h1>
			</div>

			<div class="panel-group" id="accordion">
				<div class="panel panel-default">
					<div class="panel-heading" id="day1-h">
						<a data-toggle="collapse" data-parent="#accordion" href="#day1">
							<h2>
								День 1. Настройка среды разработки
							</h2>
						</a>
					</div>

					<div id="day1" class="panel-collapse collapse in">
						<div class="panel-body">
							<ul>
								<li>На какой операционной системе работать?</li>

								<li>Коротко о графических редакторах. Какую версию Photoshop установить?</li>

								<li>Google Chrome и другие браузеры. Каковы отличия?</li>

								<li>Методы кроссбраузерного тестирования.</li>

								<li>Разбираемся с "Инструментами разработчика" в Google Chrome.</li>

								<li>Коротко о редакторах кода. Sublime Text 3 и полезные плагины для него.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day2-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day2">
							<h2>
								День 2. Анализ макета
							</h2>
						</a>
					</div>

					<div id="day2" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Введение в проблематику вопроса.</li>
								<li>Общие и технические аспекты анализа макета.</li>
								<li>Пример плохого и хорошего макета. В чем отличия?</li>
								<li>Анализ макета, который верстается в этом курсе.</li>
								<li>Немного об особенностях работы на фрилансе.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day3-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day3">
							<h2>
								День 3. Извлечение графики из макета
							</h2>
						</a>
					</div>

					<div id="day3" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Типы графических форматов: растровые и векторные.</li>
								<li>О формате SVG.</li>
								<li>Немного о формате SVG.</li>
								<li>Способы перевода растрового изображения в векторное.</li>
								<li>Извлечение графики из макета курса: "старый" и "новый" способы.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day4-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day4">
							<h2>
								День 4. Начало верстки HTML-каркаса
							</h2>
						</a>
					</div>

					<div id="day4" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Введение и немного истории: от табличной верстки к блочной.</li>
								<li>Семантика HTML и алгоритм HTML Outline.</li>
								<li>Старый алгоритм: HTML 4 Outline.</li>
								<li>Новый алгоритм: HTML5 Outline.</li>
								<li>Подключение Bootstrap и верстка HTML-каркаса макета Jetro.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day5-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day5">
							<h2>
								День 5. Настройка Bootstrap и начало стилизации
							</h2>
						</a>
					</div>

					<div id="day5" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Сборщик Bootstrap’a для тонкой настройки фрейморка.</li>
								<li>Подбор значений переменных под верстаемый макет.</li>
								<li>Брейкпоинты (breakpoints), медиа-запросы (media queries) и ширина макета.</li>
								<li>Препроцессор Less и основы работы с ним.</li>
								<li>Кроссбраузерное подключение шрифтов.</li>
								<li>Стилизация главного меню и слайдера.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day6-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day6">
							<h2>
								День 6 и 7. Окончание стилизации<br>
								и "прикрутка" адаптивности
							</h2>
						</a>
					</div>

					<div id="day6" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Что такое Flexbox’ы и как с ними работать.</li>
								<li>Стилизация оставшихся секций.</li>
								<li>Адаптивность и отзывчивость. Что к чему?</li>
								<li>Реализация адаптивности на макете курса.</li>
							</ul>
						</div>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading" id="day7-h">
						<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#day7">
							<h2>
								День 8. Оптимизация веб-страницы<br>
								(только для категории участия STEP-BY-STEP)
							</h2>
						</a>
					</div>

					<div id="day7" class="panel-collapse collapse">
						<div class="panel-body">
							<ul>
								<li>Анализ скорости загрузки страницы через Инструменты Разработчика в Google Chrome.</li>
								<li>Минификация HTML, CSS и JS-файлов.</li>
								<li>Уменьшение размера Bootstrap.</li>
								<li>CDN-сервисы, что это и зачем нужно</li>
								<li>Оптимизация селекторов в стилевых файлах.</li>
								<li>Сжатие графики JPG, PNG и SVG. Кодирование в base64.</li>
								<li>Удаление лишних файлов.</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- Отзывы -->
	<section id="testimonials">
		<div class="container">
			<div class="header grey">
				<h1>Отзывы участников курса</h1>
			</div>

			<div class="col-md-8 col-md-offset-2">
				<div class="testimonial first testimonial-left clearfix">
					<img src="images/testimonials/bronnikov_aleksey.jpg" alt="Ученик Бронников Алексей" class="img-circle">
					<span class="arrow"></span>

					<div>
						<!--
						<iframe width="100%" height="350" src="https://www.youtube.com/embed/pQqtdVJ5aU4" frameborder="0" allowfullscreen></iframe>
						-->

						<i>Бронников Алексей</i>
					</div>
				</div>

				<hr>

				<div class="testimonial testimonial-right clearfix">
					<img src="images/testimonials/sergey_petrov.jpg" alt="Ученик Сергей Петров" class="img-circle">
					<span class="arrow"></span>

					<div>
						<!--
						<iframe width="100%" height="350" src="https://www.youtube.com/embed/Cg_hv7afopU" frameborder="0" allowfullscreen></iframe>
						-->

						<i>Сергей Петров</i>
					</div>
				</div>

				<hr>

				<div class="testimonial first testimonial-left clearfix">
					<img src="images/testimonials/aleksey_ivanov.jpg" alt="Ученик Алексей Иванов" class="img-circle">
					<span class="arrow"></span>

					<div>
						<!--
						<iframe width="100%" height="350" src="https://www.youtube.com/embed/f4Ukl3WVJ7c" frameborder="0" allowfullscreen></iframe>
						-->

						<i>Алексей Иванов</i>
					</div>
				</div>

				<hr>

				<div class="testimonial testimonial-right clearfix">
					<img src="images/testimonials/semenuha_oleg.jpg" alt="Ученик Семенуха Олег" class="img-circle">
					<span class="arrow"></span>

					<div>
						<p>"Молодцы ребята! Очень качественный и насыщенный контент, много полезных и важных советов. Вообще много информации. Новичку, как мне конечно не просто, но если очень стараться, то должно все получиться :) А самое главное, обратная связь (домашние задания) для ВИП, для новичка без этого вообще никак. Спасибо!"</p>

						<i>Семенуха Олег</i>
					</div>
				</div>

				<hr>

				<div class="testimonial testimonial-left clearfix">
					<img src="images/testimonials/duster_andrey.jpg" alt="Ученик Дюстер Андрей" class="img-circle">
					<span class="arrow"></span>

					<div>
						<p>"Здравствуйте. Я участвовал в курсе по адаптивной верстке web-страницы с использованием Bootstrap. Честно говоря, в подобном формате обучения работал в первый раз. Мне очень понравилось, как ребята всё организовали. Я считаю что все заявленные обещания были выполнены и даже конкурс был. Спасибо большое, буду еще участвовать! :)"</p>

						<i>Дюстер Андрей</i>
					</div>
				</div>

				<hr>

				<div class="testimonial testimonial-right clearfix">
					<img src="images/testimonials/aliev_ruslan.jpg" alt="Ученик Алиев Руслан" class="img-circle">
					<span class="arrow"></span>

					<div>
						<p>"Огромное спасибо за курс, все очень качественно, дружелюбно и познавательно! Очень нравится как проверяется ДЗ, внимание ко всем мелочам! Жду еще мероприятий!"</p>

						<i>Алиев Руслан</i>
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- Цены -->
	<section id="prices" class="container">
		<div class="header">
			<h1>Стоимость курса</h1>
		</div>

		<!-- Счетчик -->
		<p class="text-center up-price">До поднятия цен осталось:</p>
		<div class="clock"></div>
		<p class="hurry-up">Успей купить по старой цене!</p>

		<!-- Блок цен -->
		<div class="price-block clearfix">
			<!-- FREE -->
			<div class="price-cat free">
				<div class="h-group">
					<h2>FREE</h2>
					<p class="sub">БЕСПЛАТНО</p>
				</div>

				<table class="table table-stripped">
					<tr>
						<td><i class="check"></i>Доступ к записи дня 1 в хорошем качестве</td>
					</tr>
					<tr>
						<td><i class="cross"></i>Доступ к текстам ДЗ и доп.материалам</td>
					</tr>
					<tr>
						<td><i class="cross"></i>Доcтуп к исходникам макета для курса</td>
					</tr>
					<tr>
						<td><i class="cross"></i>ВИДЕООТВЕТЫ по домашним заданиям</td>
					</tr>
					<tr>
						<td><i class="check"></i>Персональный урок:<br>700 руб/час</td>
					</tr>
				</table>

				<a href="http://www.paywithapost.de/pay?id=31730b6c-cf80-4769-80a4-8e3f647a004a" target="_blank" class="btn btn-large btn-danger">Записаться</a>

				<p id="note">* доступ за репост</p>
			</div>

			<!-- STEP-BY-STEP -->
			<div class="price-cat step-by-step">
				<div class="h-group">
					<h2>STEP-BY-STEP</h2>
					<p class="sub"><span>8000</span> 4000<span>руб</span></p>
				</div>

				<table class="table table-stripped">
					<tr>
						<td><i class="check"></i>Доступ к записям курса в хорошем качестве</td>
					</tr>
					<tr>
						<td><i class="check"></i>Доступ к текстам ДЗ и доп.материалам</td>
					</tr>
					<tr>
						<td><i class="check"></i>Доcтуп к исходникам макета для курса</td>
					</tr>
					<tr>
						<td><i class="check"></i>ВИДЕООТВЕТЫ по домашним заданиям</td>
					</tr>
					<tr>
						<td><i class="check"></i>Персональный урок:<br>500 руб/час</td>
					</tr>
				</table>

				<a href="<?php
					$param = $_GET['s'];
					if ($param === 'y') {
						echo 'http://makewebme.justclick.ru/order/verstka-base-course-step-by-step-f/';
					} else {
						echo 'http://makewebme.justclick.ru/order/verstka-base-course-step-by-step/';
					}
				?>" target="_blank" class="btn btn-large btn-danger">Оплатить</a>
			</div>

			<!-- STANDARD -->
			<div class="price-cat standard">
				<div class="h-group">
					<h2>STANDARD</h2>
					<p class="sub"><span>1600</span> 800<span>руб</span></p>
				</div>

				<table class="table table-stripped">
					<tr>
						<td><i class="check"></i>Доступ к записям курса в хорошем качестве</td>
					</tr>
					<tr>
						<td><i class="check"></i>Доступ к текстам ДЗ и доп.материалам</td>
					</tr>
					<tr>
						<td><i class="check"></i>Доcтуп к исходникам макета для курса</td>
					</tr>
					<tr>
						<td><i class="cross"></i>ВИДЕООТВЕТЫ по домашним заданиям</td>
					</tr>
					<tr>
						<td><i class="check"></i>Персональный урок:<br>600 руб/час</td>
					</tr>
				</table>

				<a href="<?php
					$param = $_GET['s'];
					if ($param === 'y') {
						echo 'http://makewebme.justclick.ru/order/verstka-base-course-standard-f/';
					} else {
						echo 'http://makewebme.justclick.ru/order/verstka-base-course-standard/';
					}
				?>" target="_blank" class="btn btn-large btn-danger">Оплатить</a>
			</div>
		</div>

		<!-- Условия и гарантии -->
		<p class="oferta text-center">Совершая покупку, вы принимаете условия <a href="http://makewebme.justclick.ru/payment/oferta" target="_blank">оферты</a>.</p>

		<div class="col-md-8 col-md-offset-2">
			<h1>Гарантии и возврат денег</h1>

			<p>Автор уверен в том, что его курс очень эффективен и полезен. Поэтому, если ты посчитаешь, что для тебя это не так, то в течении месяца с момента оплаты ты можешь вернуть всю затраченную сумму обратно.</p>

			<p>Если претензия будет обоснована, то мы вернем тебе сумму, потраченную на покупку курса и внесем изменения, чтобы сделать его лучше. В противном случае, обратно деньги ты все равно сможешь получить, но будешь внесен в "черный список" и не сможешь получить в будущем бонусов и скидок.</p>
		</div>
	</section>


	<!-- Вопросы через ВК-виджет -->
	<!--
	<section class="questions container">
		<h1>Есть вопрос? Задай!</h1>
		<div id="vk_comments"></div>
		<script>
			VK.Widgets.Comments("vk_comments", {limit: 10, attach: "*"});
		</script>
	</section>
	-->

	<!-- Футер -->
	<footer>
		<div class="container text-left">
			<div class="col-sm-6">
				<p>
					<strong>MakeWeb.me © 2015</strong>. Все права защищены.
				</p>

				<p>
					<strong>ИП Красник С.А.</strong><br>
					<strong>ИНН/ОГРН</strong>: 010404618670/315010500009251<br>
					<strong>Физический адрес</strong>: 344039, Ростовская область,<br>
					г.Ростов-на-Дону, ул.8 Марта, д.71<br>
					<strong>Телефон:</strong> +7-925-836-59-51<br>
					<strong>E-mail:</strong> makewebme.russia@gmail.com
				</p>
			</div>

			<div class="col-sm-6 social">
				<p><strong>Мы в социальных сетях:</strong></p>

				<ul class="clearfix">
					<li><a href="https://vk.com/makewebme" target="_blank" class="vk"></a></li>
					<li><a href="https://www.youtube.com/channel/UCt36CWL85NGtOgUMZ2X6x5g" target="_blank" class="yt"></a></li>
					<li><a href="https://www.facebook.com/makewebme" target="_blank" class="fb"></a></li>
					<li><a href="https://twitter.com/makewebme" target="_blank" class="tw"></a></li>
					<li><a href="https://plus.google.com/u/3/102830249147019977828/posts" target="_blank" class="gp"></a></li>
				</ul>
			</div>
		</div>
	</footer>


	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

	<!--
	<script src='js/main.min.js'></script>
	-->

	<!--[if lte IE 9]>
		<script src="js/transition.min.js"></script>
	<![endif]-->

	<?php require_once 'utm/counter.php'; ?>

	<script>
		$(document).ready(function() {
			$('.info').prependTo('body');
		});
	</script>

</body>
</html>