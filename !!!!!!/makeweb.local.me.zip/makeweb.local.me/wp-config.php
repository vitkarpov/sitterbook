<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'makewebme');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'd-Q=,cgNo@z93|oMT`Y/&doe?1zoR.:d!&qVqQdF|KIe9SG++N>/8#+J1Op-v2o:');
define('SECURE_AUTH_KEY',  '?jd+2?2gc=a#+O=LB&}8<xfm`!B621+1!Syy-A~QNO)7tWOPDN;*[2SWuG)}X;Pk');
define('LOGGED_IN_KEY',    '1k }EL+vsiI7)*$_f>n}qt?oARvM=$e7o}C/kdWr<ca*o?Mzj)iEd;Zd@svv&./`');
define('NONCE_KEY',        '.O5jAGI2%g@{/u7v1J):3kR@-OQHx2,b3AEDQ/U41QBB a$feikK,-p7(^>K(q2D');
define('AUTH_SALT',        'V|{WKU|:U}YzM+L1h)g#JO]xuoI}3al>rAO;_U|DKkPZ2k3Oc>|rqEJw8w9H&gLH');
define('SECURE_AUTH_SALT', '1PJLK]+JA]lq)S-{-O(h4Yr_?aHvHE$W<|ozxDw~h26?5]v$kQzE#:FR[kXvCWmY');
define('LOGGED_IN_SALT',   'ErqKQ7m:$t+#OrEh?Jj+IuI)%5f.-+Ej[QZ4RJJ|v/w-d~kXF7L_7,gKKb6$K>o!');
define('NONCE_SALT',       '{%$3_O|NFldZRqo5YT_iw*!98cJm0A(lR:#hRY[yV5Hylz1+WC^yBtcniL|x`QVx');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'mw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
