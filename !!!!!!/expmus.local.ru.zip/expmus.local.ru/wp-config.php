<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи и ABSPATH. Дополнительную информацию можно найти на странице
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется скриптом для создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения вручную.
 *
 * @package WordPress
 */

define('WP_HOME','http://localhost:8888/expmus.local.ru/');
define('WP_SITEURL','http://localhost:8888/expmus.local.ru/');

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'expmus'); // user24561_expmus

/** Имя пользователя MySQL */
define('DB_USER', 'root'); // user24561_expmus

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'root'); // pwmBDcbfoZNm

/** Имя сервера MySQL */
define('DB_HOST', 'localhost'); // mysql-18.smartape.ru

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4'); // utf8

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'wZ]W7s*O*!>+%!Q6fcPJRahYe!YGMIqjW/MC]`R8mjiCOuvN%E$>W@pz1,UZ8V>t');
define('SECURE_AUTH_KEY',  '1MFp-L^g;=Q^=,tZ,kKS|E;?C3`goWq@zgVl~f,A,=.`3fIWAeE$8dHqimaIp]dY');
define('LOGGED_IN_KEY',    'tm~1-/I>[o:6>/3]*6J;<3oA~kN/r&l?4SA!WRT8CghrCc78;1:Q{Xt{DG>V!xlj');
define('NONCE_KEY',        '{+S?qhj{$,6NQ}$F<X?,AJNGNU<z6UTQT=.28mR3{?OyfK|6VeZD<8+/,}336a;c');
define('AUTH_SALT',        '<S{g3d%,cwwedkq$V!{|~?-!Yw.ur|YRnB1]-6Hd{ijMLuY|u5(slxrS9#xR>sBn');
define('SECURE_AUTH_SALT', '}JA~eQU!UXMAYy2+3fseqf8dI2od~FIF_-n}TeL]DJBg#xOQ!=@3UdP;+{iUE I(');
define('LOGGED_IN_SALT',   'PnCH+1UEENU&NDd%H,Z|9>T;r=?tRIFW;a@/qiIGH_Dt0T( XdE!ChQWWMFRJ=B#');
define('NONCE_SALT',       '}Y?Xw3}PWVU0k!^c`TC0m1gIP*Ww{_my:RO9fxx-ZD#UvMH@l-C`BxUp?J;$Q6,@');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'expmus_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', true);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
  define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
